# ColorClock
A minimalist, fast-loading Google Chrome extension that shows HEX color code and time as new tab page.

![](http://i.imgur.com/o8PVSeH.png)

## Install
Available at [Chrome Web Store](https://chrome.google.com/webstore/detail/new-tab-color-clock/dfkbogglcileimhledhafjnggcjfkgkj)

## Screenshots
![](http://i.imgur.com/yRvDC74.gif)
![](http://i.imgur.com/gaf5Quw.png)
![](http://i.imgur.com/kwDi3lJ.png)
