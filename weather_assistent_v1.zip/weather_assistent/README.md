# The Weather assistent

![](http://i.imgur.com/o8PVSeH.png)

## Install
Available at [Chrome Web Store]()

## Screenshots
![]
![]
![]
